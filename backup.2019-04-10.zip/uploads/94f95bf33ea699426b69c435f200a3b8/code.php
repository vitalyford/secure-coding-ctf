<?php

if(strpos($address,"cat")===false){
}else{
	
	echo "NOT ALLOWED!"; 
	die();
	
	
	}

?>