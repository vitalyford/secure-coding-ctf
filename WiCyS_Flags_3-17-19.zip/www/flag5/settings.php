<?php
$actualPass="asfsfnnfndfaiusfniurn344nf348f3948f43j98jOFJFSDOJDFO";
$flag="{ABC00617-9D4C-4C4C-AC06-21ED94B03042}";
?>