<?php

echo "Chat/login temporarily suspended";

?>