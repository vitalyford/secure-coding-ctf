<?php function answer(){echo "{BE0B3E0A-843B-45BB-B7F9-54683B1D0CC4}";} 
//12002011201
?>
